/**
 * Written by Gil Tene of Azul Systems, and released to the public domain,
 * as explained at http://creativecommons.org/publicdomain/zero/1.0/
 *
 * @author Gil Tene
 */

package org.jhiccup;

public final class Version {
    public static final String version="2.0.2";
    public static final String build_time="20140424-1705";
}
